from django.contrib import admin

from detector.models import MalwareDetection

# Register your models here.
admin.site.register(MalwareDetection)